#! /bin/bash
paste -d '\n' $1 $2
